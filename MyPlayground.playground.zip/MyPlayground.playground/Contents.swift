import UIKit

// commend
var str = "Hello, playground"
print(str)
str="some data"

print(str)
let con="constant"
print(con)

var b:Bool=true
print(b)

var i:Int=32
//after  that only  int because 32=int
i=0
i = -10
//// ne moje (float)   i = 0.4569

var f = 0.3493
//var f:Double=0.4543
print(i)
print(f)

