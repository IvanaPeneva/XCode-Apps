import UIKit

var a = 20-5
print(a)
var g = sqrt(36)
print(g)


