import UIKit
//1
var str = "Hello, playground"
func GoodMorning() {
    print("Goood Morning!")
}
GoodMorning()
//2 und 3
func printTotalWhTax (x:Double) -> Double {

    return x*1.13
}
print(printTotalWhTax(x: 10))

//4
func calculateTotalWhTax (subtotal:Double, tax:Double) -> Double{
    return subtotal * tax
}
print(calculateTotalWhTax(subtotal: 60, tax: 1.23))
