import UIKit

class Spaceship {
    
    var fuelLevel = 100 //property of the class
    var name = "" //sets the data type
    
    func cruise() {
        print("Cruising is initiated for \(name)")

    }
    
    func thrust (){
        print("Rocket thrusters initiated for \(name)")

    }
}
var myshipp = Spaceship() //the data type is now Spaceship
myshipp.name = "Mart"
myshipp.cruise()
print(myshipp.name)
print(myshipp.fuelLevel)
