import UIKit

func vowelDetectot (a:String) -> Bool {
    if a.contains("a") ||
    a.contains("e") ||
    a.contains("i") ||
    a.contains ("u") ||
        a.contains("o") {
        return true
    }
    else{
        return false
    }
}
print(vowelDetectot(a: "sync"))
print(vowelDetectot(a: "hello"))
